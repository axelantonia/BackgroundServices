import { useState, useEffect } from "react";
import { semuaMenu } from "./data/menu";
import Panel from "./components/Panel";
import FilterBar from "./components/FilterBar";
import MenuList from "./components/MenuList";
import Keranjang from "./components/Keranjang";
import TimerSesi from "./components/TimerSesi";
import FormTambahMenu from "./components/FormTambahMenu";
import styles from "./App.module.css";

const KUNCI = "kantinkita-keranjang";

function bacaKeranjang() {
  return JSON.parse(localStorage.getItem(KUNCI)) || [];
}

export default function App() {
  const [menu, setMenu] = useState(semuaMenu);
  const [keyword, setKeyword] = useState("");
  const [kategori, setKategori] = useState("semua");
  const [keranjang, setKeranjang] = useState(bacaKeranjang);
  const [tampilTimer, setTampilTimer] = useState(true);
  const [waktuMulai] = useState(() => Date.now());

  // nilai turunan
  const daftarKategori = [...new Set(menu.map((m) => m.kategori))];
  const infoKategori = [
    { nama: "semua", jumlah: menu.length },
    ...daftarKategori.map((k) => ({
      nama: k,
      jumlah: menu.filter((m) => m.kategori === k).length,
    })),
  ];

  const hasil = menu.filter(
    (m) =>
      m.nama.toLowerCase().includes(keyword.trim().toLowerCase()) &&
      (kategori === "semua" || m.kategori === kategori)
  );

  const totalItem = keranjang.reduce((acc, i) => acc + i.qty, 0);
  const totalHarga = keranjang.reduce((acc, i) => acc + i.qty * i.harga, 0);

  // simpan keranjang ke localStorage
  useEffect(() => {
    localStorage.setItem(KUNCI, JSON.stringify(keranjang));
  }, [keranjang]);

  // judul tab browser
  useEffect(() => {
    document.title = totalItem > 0 ? `(${totalItem}) KantinKita` : "KantinKita";
  }, [totalItem]);

  const tambahKeKeranjang = (item) => {
    setKeranjang((prev) =>
      prev.some((i) => i.id === item.id)
        ? prev.map((i) => (i.id === item.id ? { ...i, qty: i.qty + 1 } : i))
        : [...prev, { id: item.id, nama: item.nama, harga: item.harga, qty: 1 }]
    );
  };

  const ubahQty = (id, selisih) => {
    setKeranjang((prev) =>
      prev
        .map((i) => (i.id === id ? { ...i, qty: i.qty + selisih } : i))
        .filter((i) => i.qty > 0)
    );
  };

  const hapusDariKeranjang = (id) => {
    setKeranjang((prev) => prev.filter((i) => i.id !== id));
  };

  const tambahMenu = (menuBaru) => {
    setMenu((prev) => [
      ...prev,
      { ...menuBaru, id: Math.max(0, ...prev.map((m) => m.id)) + 1 },
    ]);
  };

  return (
    <div className={styles.halaman}>
      <header className={styles.header}>
        <h1>KantinKita</h1>
        {tampilTimer && <TimerSesi waktuMulai={waktuMulai} />}
        <button onClick={() => setTampilTimer((t) => !t)}>
          {tampilTimer ? "Sembunyikan timer" : "Tampilkan timer"}
        </button>
      </header>

      <main className={styles.isi}>
        <aside className={styles.kiri}>
          <Panel judul="Tambah menu">
            <FormTambahMenu daftarKategori={daftarKategori} onTambah={tambahMenu} />
          </Panel>
        </aside>

        <section className={styles.tengah}>
          <Panel judul="Menu">
            <FilterBar
              keyword={keyword}
              onKeywordChange={setKeyword}
              kategoriAktif={kategori}
              onKategoriChange={setKategori}
              infoKategori={infoKategori}
            />
            <MenuList
              daftar={hasil}
              keyword={keyword}
              kategori={kategori}
              onTambah={tambahKeKeranjang}
            />
          </Panel>
        </section>

        <aside className={styles.kanan}>
          <Panel judul={`Keranjang (${totalItem} item)`}>
            <Keranjang
              items={keranjang}
              totalHarga={totalHarga}
              onUbahQty={ubahQty}
              onHapus={hapusDariKeranjang}
            />
          </Panel>
        </aside>
      </main>
    </div>
  );
}
