import Badge from "./Badge";
import styles from "./MenuCard.module.css";

export default function MenuCard({ menu, onTambah }) {
  const habis = menu.stok === 0;

  return (
    <article className={`${styles.card} ${habis ? styles.habis : ""}`}>
      <h3>{menu.nama}</h3>
      <p className={styles.harga}>Rp {menu.harga.toLocaleString("id-ID")}</p>
      {habis ? (
        <Badge warna="merah">Habis</Badge>
      ) : (
        <Badge>Stok {menu.stok}</Badge>
      )}
      <button
        className={styles.tambah}
        disabled={habis}
        onClick={() => onTambah(menu)}
      >
        Tambah
      </button>
    </article>
  );
}
