import { useRef } from "react";
import styles from "./FilterBar.module.css";

export default function FilterBar({
  keyword,
  onKeywordChange,
  kategoriAktif,
  onKategoriChange,
  infoKategori,
}) {
  const inputRef = useRef(null);

  const bersihkan = () => {
    onKeywordChange("");
    inputRef.current.focus();
  };

  return (
    <div className={styles.bar}>
      <label htmlFor="cari">Cari menu</label>
      <div className={styles.cari}>
        <input
          id="cari"
          ref={inputRef}
          type="text"
          placeholder="Ketik nama menu..."
          value={keyword}
          onChange={(e) => onKeywordChange(e.target.value)}
        />
        <button onClick={bersihkan}>Bersihkan</button>
      </div>
      <div className={styles.kategori}>
        {infoKategori.map((k) => (
          <button
            key={k.nama}
            className={`${styles.tombol} ${kategoriAktif === k.nama ? styles.aktif : ""}`}
            onClick={() => onKategoriChange(k.nama)}
          >
            {k.nama} ({k.jumlah})
          </button>
        ))}
      </div>
    </div>
  );
}
