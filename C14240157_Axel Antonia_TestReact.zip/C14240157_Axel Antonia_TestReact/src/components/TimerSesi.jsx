import { useState, useEffect } from "react";

export default function TimerSesi({ waktuMulai }) {
  const [sekarang, setSekarang] = useState(() => Date.now());

  useEffect(() => {
    const id = setInterval(() => {
      setSekarang(Date.now());
    }, 1000);

    return () => clearInterval(id);
  }, []);

  const totalDetik = Math.floor((sekarang - waktuMulai) / 1000);
  const mm = String(Math.floor(totalDetik / 60)).padStart(2, "0");
  const ss = String(totalDetik % 60).padStart(2, "0");

  return <span>Sesi: {mm}:{ss}</span>;
}
