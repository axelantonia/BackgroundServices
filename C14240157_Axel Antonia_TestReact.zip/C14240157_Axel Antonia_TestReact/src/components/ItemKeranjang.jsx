import { useState } from "react";
import styles from "./ItemKeranjang.module.css";

export default function ItemKeranjang({ item, onUbahQty, onHapus }) {
  const [konfirmasi, setKonfirmasi] = useState(false);

  return (
    <li className={styles.item}>
      <span>
        {item.nama} (Rp {item.harga.toLocaleString("id-ID")})
      </span>
      <div className={styles.aksi}>
        <button onClick={() => onUbahQty(item.id, -1)}>-</button>
        <span>{item.qty}</span>
        <button onClick={() => onUbahQty(item.id, 1)}>+</button>
        {konfirmasi ? (
          <>
            <button onClick={() => onHapus(item.id)}>Yakin?</button>
            <button onClick={() => setKonfirmasi(false)}>Batal</button>
          </>
        ) : (
          <button onClick={() => setKonfirmasi(true)}>Hapus</button>
        )}
      </div>
    </li>
  );
}
