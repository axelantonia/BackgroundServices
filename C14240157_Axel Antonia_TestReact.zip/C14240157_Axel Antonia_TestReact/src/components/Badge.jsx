import styles from "./Badge.module.css";

export default function Badge({ children, warna = "hijau" }) {
  return <span className={`${styles.badge} ${styles[warna]}`}>{children}</span>;
}
