import MenuCard from "./MenuCard";
import styles from "./MenuList.module.css";

export default function MenuList({ daftar, keyword, kategori, onTambah }) {
  if (daftar.length === 0) {
    const kata = keyword.trim();
    const pesanKata = kata ? ` dengan kata kunci "${kata}"` : "";
    const pesanKategori = kategori !== "semua" ? ` pada kategori "${kategori}"` : "";
    return <p>Tidak ada menu{pesanKata}{pesanKategori}.</p>;
  }

  return (
    <div className={styles.grid}>
      {daftar.map((item) => (
        <MenuCard key={item.id} menu={item} onTambah={onTambah} />
      ))}
    </div>
  );
}
