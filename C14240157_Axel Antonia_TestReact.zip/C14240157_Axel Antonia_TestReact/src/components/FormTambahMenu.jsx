import { useState } from "react";
import styles from "./FormTambahMenu.module.css";

const NILAI_AWAL = { nama: "", kategori: "", harga: "", stok: "" };

export default function FormTambahMenu({ daftarKategori, onTambah }) {
  const [form, setForm] = useState(NILAI_AWAL);
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const validasi = () => {
    const err = {};
    if (form.nama.trim().length < 3) err.nama = "Nama minimal 3 karakter.";
    if (!form.kategori) err.kategori = "Kategori wajib dipilih.";
    if (form.harga === "" || Number(form.harga) <= 0) err.harga = "Harga harus lebih dari 0.";
    if (form.stok === "" || Number(form.stok) < 0) err.stok = "Stok tidak boleh negatif.";
    return err;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const err = validasi();
    setErrors(err);
    if (Object.keys(err).length > 0) return;

    onTambah({
      nama: form.nama.trim(),
      kategori: form.kategori,
      harga: Number(form.harga),
      stok: Number(form.stok),
    });
    setForm(NILAI_AWAL);
  };

  return (
    <form className={styles.form} onSubmit={handleSubmit} noValidate>
      <label htmlFor="nama">Nama</label>
      <input id="nama" name="nama" value={form.nama} onChange={handleChange} />
      {errors.nama && <small className={styles.error} role="alert">{errors.nama}</small>}

      <label htmlFor="kategori">Kategori</label>
      <select id="kategori" name="kategori" value={form.kategori} onChange={handleChange}>
        <option value="">-- Pilih --</option>
        {daftarKategori.map((k) => (
          <option key={k} value={k}>{k}</option>
        ))}
      </select>
      {errors.kategori && <small className={styles.error} role="alert">{errors.kategori}</small>}

      <label htmlFor="harga">Harga</label>
      <input id="harga" name="harga" type="number" value={form.harga} onChange={handleChange} />
      {errors.harga && <small className={styles.error} role="alert">{errors.harga}</small>}

      <label htmlFor="stok">Stok</label>
      <input id="stok" name="stok" type="number" value={form.stok} onChange={handleChange} />
      {errors.stok && <small className={styles.error} role="alert">{errors.stok}</small>}

      <button type="submit">Simpan menu</button>
    </form>
  );
}
