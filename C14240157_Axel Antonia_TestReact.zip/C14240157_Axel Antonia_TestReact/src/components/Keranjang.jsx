import ItemKeranjang from "./ItemKeranjang";
import styles from "./Keranjang.module.css";

export default function Keranjang({ items, totalHarga, onUbahQty, onHapus }) {
  if (items.length === 0) {
    return <p>Keranjang kosong.</p>;
  }

  return (
    <>
      <ul className={styles.daftar}>
        {items.map((item) => (
          <ItemKeranjang
            key={item.id}
            item={item}
            onUbahQty={onUbahQty}
            onHapus={onHapus}
          />
        ))}
      </ul>
      <p className={styles.total}>Total: Rp {totalHarga.toLocaleString("id-ID")}</p>
    </>
  );
}
