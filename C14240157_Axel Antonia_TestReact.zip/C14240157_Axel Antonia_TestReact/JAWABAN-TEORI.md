1. useState tidak boleh diletakkan di dalam if karena Hook harus dipanggil di bagian atas komponen. React mengenali state berdasarkan urutan pemanggilan Hook, bukan namanya. Jika useState hanya dipanggil saat kondisi tertentu terpenuhi, urutannya bisa berubah dan membuat React salah membaca state. Solusinya, letakkan useState di bagian atas komponen, lalu gunakan if untuk mengatur kondisi.

function Profil({ sudahLogin }) {
  const [nama, setNama] = useState("");

  if (sudahLogin) { //nama disini }
}

2. items.push(baru) menambahkan data ke array lama, sehingga array-nya tetap sama. React mengira tidak ada perubahan karena referensi array tidak berubah, akibatnya tampilan tidak diperbarui. Solusinya, buat array baru menggunakan [...prev, baru].

const tambah = (baru) => {
  setItems((prev) => [...prev, baru]);
};

3. (a) Tanpa dependency array, efek dijalankan setiap kali komponen dirender. Jika efek memanggil setState, hal ini bisa menyebabkan render terus-menerus (infinite loop). 
(b) [], efek dijalankan satu kali saat komponen pertama kali ditampilkan (mount). 
(c) [kota], efek dijalankan saat komponen pertama kali ditampilkan dan setiap kali nilai kota berubah. Fungsi cleanup dijalankan sebelum efek dijalankan kembali ketika dependensi berubah dan saat komponen dihapus (unmount).

4. State keyword disimpan di komponen induk (misalnya App) karena digunakan oleh kedua komponen. Induk mengirim nilai keyword dan fungsi untuk mengubahnya ke komponen anak melalui props. Saat pengguna mengubah keyword di FilterBar, komponen tersebut memanggil fungsi dari induk agar nilai state diperbarui. Dengan begitu, kedua komponen menggunakan data yang sama dan aliran data tetap satu arah.

5. Controlled component adalah input yang nilainya diatur oleh state React. Nilai input diambil dari value, sedangkan onChange digunakan untuk memperbarui state saat pengguna mengetik. Satu fungsi handleChange bisa menangani banyak input karena setiap input memiliki atribut name yang sesuai dengan nama properti di state. Dengan [name] dan ...prev, fungsi dapat memperbarui properti yang tepat tanpa menghapus data lainnya.